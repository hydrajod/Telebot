# StockPilot AI

A Node.js Telegram bot for Indian NSE stock research. It combines 5-minute OHLCV candles, technical indicators and Gemini explanations. It does not execute trades.

## Requirements

- Node.js 22+
- Telegram bot token from @BotFather
- Twelve Data API key with access to the NSE symbols and intraday interval you want
- Gemini API key
- MongoDB Atlas connection string

## Install

```bash
npm install
cp .env.example .env
```

Fill in `.env`. Never commit `.env` or share API keys.

## Run locally

```bash
npm start
```

Open your Telegram bot and send `/start`.

## Commands

- `/start`
- `/help`
- `/market`
- `/analysis RELIANCE`
- `/watchlist`
- `/add INFY`
- `/remove INFY`
- `/subscribe`
- `/unsubscribe`

## Scheduled alerts

The scheduler scans the configured `STOCK_UNIVERSE` at 09:25, 12:30 and 15:15 Asia/Kolkata time, Monday to Friday. It sends qualifying non-WAIT setups with Gemini explanations to subscribed users. Exchange holidays are not automatically excluded. Keep the cloud service running continuously for scheduled jobs.

## Deploy to a cloud host

Create a Node.js web service from this repository.

- Build command: `npm install`
- Start command: `npm start`
- Health check path: `/health`
- Add every variable from `.env.example` in the host's environment-variable settings.
- Use an always-on service. A sleeping/free web service cannot reliably run polling and scheduled jobs.

Do not run multiple replicas of this polling bot with the same token unless you implement a distributed scheduler and webhook/worker architecture. Multiple polling instances can conflict.

## Market data notes

The app requests `time_series` from Twelve Data using `exchange=NSE`, `interval=5min`, `timezone=Asia/Kolkata`. Confirm that each symbol is recognized by the provider and that your API plan permits the needed exchange, intraday history and real-time/delayed entitlement. Provider quotas and exchange fees may apply. A successful API response does not automatically mean the data is real-time.

## Signal methodology

Bullish candidate requires:
- Last close above EMA20
- EMA20 above EMA50
- RSI(14) between 50 and 68
- Positive MACD histogram
- Latest candle volume at least the configured multiple of the previous 20-candle average

The stop and target are illustrative ATR-based levels (1.5 ATR stop, 2R target). They are not guaranteed execution prices. The bearish state is a watch/avoid-long classification, not an instruction to short.

## Important limitations

- Technical indicators are calculated from provider candles, which may be delayed, incomplete or adjusted.
- No corporate-news, circuit-limit, liquidity, spread, volatility halt or exchange-holiday filter is included in this starter version.
- It is not a SEBI-registered investment adviser or a broker.
- Do not treat a signal as personalized investment advice. Verify prices and risk independently.
- Paper-test and backtest before considering any real-money use.
