import "dotenv/config";

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export const config = {
  botToken: required("BOT_TOKEN"),
  twelveDataKey: required("TWELVE_DATA_API_KEY"),
  geminiKey: required("GEMINI_API_KEY"),
  geminiModel: process.env.GEMINI_MODEL || "gemini-2.5-flash",
  mongoUri: required("MONGODB_URI"),
  port: Number(process.env.PORT || 3000),
  symbols: (process.env.STOCK_UNIVERSE || "RELIANCE,HDFCBANK,ICICIBANK,SBIN,INFY,TCS,ITC,BHARTIARTL,LT,AXISBANK")
    .split(",").map(s => s.trim().toUpperCase()).filter(Boolean),
  interval: process.env.CANDLE_INTERVAL || "5min",
  outputsize: Math.max(80, Number(process.env.CANDLE_OUTPUTSIZE || 120)),
  minVolumeRatio: Number(process.env.MIN_VOLUME_RATIO || 1.2)
};
