import express from "express";
import { config } from "./config.js";
import { connectDatabase } from "./database.js";
import { bot } from "./bot.js";
import { startScheduler } from "./jobs/scheduler.js";

const app = express();
app.get("/", (_req, res) => res.status(200).send("StockPilot AI is running."));
app.get("/health", (_req, res) => res.json({ status: "ok", service: "stockpilot-ai" }));

async function main() {
  await connectDatabase();

  app.listen(config.port, () => {
    console.log(`Health server listening on port ${config.port}`);
  });

  await bot.launch();
  console.log("Telegram bot started using long polling.");
  startScheduler();
}

main().catch(error => {
  console.error("Startup failed:", error);
  process.exit(1);
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
