import { GoogleGenAI } from "@google/genai";
import { config } from "../config.js";

const ai = new GoogleGenAI({ apiKey: config.geminiKey });

export async function explainSignal(symbol, metrics) {
  const prompt = `
You are a cautious Indian equity market research explainer.
Explain the supplied, already-calculated technical data in 3-5 concise bullet points.
Do not invent prices, news, fundamentals, events, or indicators.
Do not change the signal classification or create a new buy/sell recommendation.
Mention uncertainty and that intraday data may be delayed depending on the provider plan.
This is educational research, not personalized financial advice.

Symbol: ${symbol}
Metrics: ${JSON.stringify(metrics)}
Signal classification: ${metrics.signal}
  `.trim();

  try {
    const result = await ai.models.generateContent({
      model: config.geminiModel,
      contents: prompt
    });
    return result.text?.trim() || "AI explanation unavailable.";
  } catch (error) {
    console.error("Gemini error:", error.message);
    return "AI explanation temporarily unavailable. The technical metrics above are calculated independently.";
  }
}
