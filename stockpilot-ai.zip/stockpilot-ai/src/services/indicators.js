function ema(values, period) {
  if (values.length < period) return null;
  const multiplier = 2 / (period + 1);
  let result = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) {
    result = values[i] * multiplier + result * (1 - multiplier);
  }
  return result;
}

function rsi(values, period = 14) {
  if (values.length <= period) return null;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const change = values[i] - values[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < values.length; i++) {
    const change = values[i] - values[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(change, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-change, 0)) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function macdHistogram(values) {
  // Build EMA series so the final MACD and signal values use aligned observations.
  const emaSeries = (arr, period) => {
    const out = Array(arr.length).fill(null);
    if (arr.length < period) return out;
    const k = 2 / (period + 1);
    let current = arr.slice(0, period).reduce((a, b) => a + b, 0) / period;
    out[period - 1] = current;
    for (let i = period; i < arr.length; i++) {
      current = arr[i] * k + current * (1 - k);
      out[i] = current;
    }
    return out;
  };

  const fast = emaSeries(values, 12);
  const slow = emaSeries(values, 26);
  const macd = values.map((_, i) =>
    fast[i] == null || slow[i] == null ? null : fast[i] - slow[i]
  );
  const valid = macd.filter(v => v != null);
  if (valid.length < 9) return null;
  const signal = ema(valid, 9);
  return valid[valid.length - 1] - signal;
}

function atr(candles, period = 14) {
  if (candles.length <= period) return null;
  const ranges = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i], prev = candles[i - 1];
    ranges.push(Math.max(
      c.high - c.low,
      Math.abs(c.high - prev.close),
      Math.abs(c.low - prev.close)
    ));
  }
  return ranges.slice(-period).reduce((a, b) => a + b, 0) / period;
}

export function analyzeCandles(candles, minVolumeRatio = 1.2) {
  const closes = candles.map(c => c.close);
  const latest = candles.at(-1);
  const previousVolumes = candles.slice(-21, -1).map(c => c.volume).filter(v => v > 0);
  const avgVolume = previousVolumes.length
    ? previousVolumes.reduce((a, b) => a + b, 0) / previousVolumes.length
    : 0;
  const volumeRatio = avgVolume > 0 && latest.volume > 0 ? latest.volume / avgVolume : null;

  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);
  const rsi14 = rsi(closes, 14);
  const macdHist = macdHistogram(closes);
  const atr14 = atr(candles, 14);

  if ([ema20, ema50, rsi14, macdHist, atr14].some(v => v == null)) {
    throw new Error("Unable to calculate all indicators for this symbol.");
  }

  const bullish = latest.close > ema20 && ema20 > ema50 &&
    rsi14 >= 50 && rsi14 <= 68 && macdHist > 0 &&
    volumeRatio != null && volumeRatio >= minVolumeRatio;

  const bearish = latest.close < ema20 && ema20 < ema50 &&
    rsi14 <= 48 && macdHist < 0;

  let score = 0;
  if (latest.close > ema20) score++;
  if (ema20 > ema50) score++;
  if (rsi14 >= 50 && rsi14 <= 68) score++;
  if (macdHist > 0) score++;
  if (volumeRatio != null && volumeRatio >= minVolumeRatio) score++;

  const risk = atr14 * 1.5;
  return {
    price: latest.close,
    datetime: latest.datetime,
    ema20, ema50, rsi14, macdHist, atr14, volumeRatio, score,
    signal: bullish ? "BUY_CANDIDATE" : bearish ? "BEARISH_WATCH" : "WAIT",
    stopLoss: bullish ? latest.close - risk : null,
    target: bullish ? latest.close + risk * 2 : null,
    riskReward: bullish ? "1:2" : null
  };
}
