import axios from "axios";
import { config } from "../config.js";

const BASE_URL = "https://api.twelvedata.com/time_series";

export async function getCandles(symbol) {
  const response = await axios.get(BASE_URL, {
    params: {
      symbol,
      exchange: "NSE",
      interval: config.interval,
      outputsize: config.outputsize,
      order: "ASC",
      timezone: "Asia/Kolkata",
      apikey: config.twelveDataKey
    },
    timeout: 20000
  });

  const data = response.data;
  if (data.status === "error" || !Array.isArray(data.values)) {
    throw new Error(data.message || `No candle data returned for ${symbol}. Check NSE symbol coverage and API plan.`);
  }

  const candles = data.values.map(row => ({
    datetime: row.datetime,
    open: Number(row.open),
    high: Number(row.high),
    low: Number(row.low),
    close: Number(row.close),
    volume: Number(row.volume || 0)
  })).filter(c =>
    Number.isFinite(c.close) && Number.isFinite(c.high) &&
    Number.isFinite(c.low) && Number.isFinite(c.volume)
  );

  if (candles.length < 60) {
    throw new Error(`Not enough candles for ${symbol}: received ${candles.length}, need at least 60.`);
  }

  return { symbol, exchange: data.meta?.exchange || "NSE", candles };
}
