import { getCandles } from "./marketData.js";
import { analyzeCandles } from "./indicators.js";
import { explainSignal } from "./aiAnalyst.js";
import { config } from "../config.js";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

export async function scanSymbol(symbol, withAI = true) {
  const { candles } = await getCandles(symbol);
  const metrics = analyzeCandles(candles, config.minVolumeRatio);
  const explanation = withAI ? await explainSignal(symbol, metrics) : "";
  return { symbol, metrics, explanation };
}

export async function scanSymbols(symbols, withAI = true) {
  const results = [];
  for (const symbol of [...new Set(symbols.map(s => s.toUpperCase()))]) {
    try {
      results.push(await scanSymbol(symbol, withAI));
    } catch (error) {
      console.error(`Scan failed for ${symbol}:`, error.message);
      results.push({ symbol, error: error.message });
    }
    // Avoid firing requests too quickly and exhausting provider quotas.
    await sleep(8000);
  }
  return results;
}

export function formatResult(result) {
  if (result.error) return `⚠️ ${result.symbol}: ${result.error}`;
  const m = result.metrics;
  const money = n => `₹${Number(n).toFixed(2)}`;
  const title = m.signal === "BUY_CANDIDATE"
    ? "🟢 BUY CANDIDATE — research signal"
    : m.signal === "BEARISH_WATCH"
      ? "🔴 BEARISH WATCH — avoid chasing longs"
      : "🟡 WAIT — no confirmed setup";

  let message = `<b>${result.symbol}</b>\n${title}\n\n` +
    `Price: <b>${money(m.price)}</b>\n` +
    `RSI(14): ${m.rsi14.toFixed(1)}\n` +
    `EMA20: ${money(m.ema20)}\n` +
    `EMA50: ${money(m.ema50)}\n` +
    `MACD histogram: ${m.macdHist.toFixed(4)}\n` +
    `Volume vs 20-candle avg: ${m.volumeRatio == null ? "N/A" : `${m.volumeRatio.toFixed(2)}x`}\n` +
    `Setup score: ${m.score}/5\n`;

  if (m.signal === "BUY_CANDIDATE") {
    message += `\nEntry reference: ${money(m.price)}\n` +
      `Illustrative stop: ${money(m.stopLoss)}\n` +
      `Illustrative target: ${money(m.target)}\n` +
      `Risk/reward: ${m.riskReward}\n`;
  }
  if (result.explanation) message += `\n<b>AI explanation</b>\n${escapeHtml(result.explanation)}\n`;
  message += `\n<i>Candle: ${escapeHtml(m.datetime)} | Verify live price, liquidity and news before acting. Research only; not a trade instruction.</i>`;
  return message;
}

function escapeHtml(text) {
  return String(text).replaceAll("&", "&amp;").replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}
