import { Telegraf } from "telegraf";
import { config } from "./config.js";
import {
  upsertUser, getUser, updateWatchlist, setSubscription
} from "./database.js";
import { scanSymbol, scanSymbols, formatResult } from "./services/scanner.js";

export const bot = new Telegraf(config.botToken);

const validSymbol = s => /^[A-Z0-9&.-]{1,25}$/.test(s);

bot.start(async ctx => {
  const user = await upsertUser(ctx);
  await ctx.reply(
    `📈 Welcome to StockPilot AI!\n\n` +
    `Your watchlist: ${user.watchlist.join(", ")}\n\n` +
    `Commands:\n` +
    `/market - scan your watchlist\n` +
    `/analysis RELIANCE - analyze one stock\n` +
    `/watchlist - show your stocks\n` +
    `/add INFY - add a stock\n` +
    `/remove INFY - remove a stock\n` +
    `/subscribe - receive scheduled reports\n` +
    `/unsubscribe - stop scheduled reports\n` +
    `/help - command guide\n\n` +
    `This bot provides technical research signals only. It does not place orders.`
  );
});

bot.help(ctx => ctx.reply(
  `/market — Scan your watchlist\n` +
  `/analysis SYMBOL — Analyze one NSE symbol\n` +
  `/watchlist — Show watchlist\n` +
  `/add SYMBOL — Add a symbol\n` +
  `/remove SYMBOL — Remove a symbol\n` +
  `/subscribe — Enable scheduled alerts\n` +
  `/unsubscribe — Disable scheduled alerts\n\n` +
  `Use NSE symbols such as RELIANCE, INFY or SBIN.`
));

bot.command("watchlist", async ctx => {
  const user = await upsertUser(ctx);
  await ctx.reply(`📋 Your watchlist:\n${user.watchlist.join("\n")}`);
});

bot.command("add", async ctx => {
  const symbol = (ctx.message.text.split(/\s+/)[1] || "").toUpperCase();
  if (!validSymbol(symbol)) return ctx.reply("Usage: /add RELIANCE");
  const user = await upsertUser(ctx);
  if (user.watchlist.includes(symbol)) return ctx.reply(`${symbol} is already in your watchlist.`);
  if (user.watchlist.length >= 30) return ctx.reply("Watchlist limit is 30 symbols.");
  user.watchlist.push(symbol);
  await updateWatchlist(String(ctx.chat.id), user.watchlist);
  await ctx.reply(`✅ Added ${symbol}. Use /analysis ${symbol} to analyze it.`);
});

bot.command("remove", async ctx => {
  const symbol = (ctx.message.text.split(/\s+/)[1] || "").toUpperCase();
  if (!validSymbol(symbol)) return ctx.reply("Usage: /remove RELIANCE");
  const user = await upsertUser(ctx);
  const next = user.watchlist.filter(s => s !== symbol);
  if (next.length === user.watchlist.length) return ctx.reply(`${symbol} was not in your watchlist.`);
  await updateWatchlist(String(ctx.chat.id), next);
  await ctx.reply(`Removed ${symbol}.`);
});

bot.command("subscribe", async ctx => {
  await upsertUser(ctx);
  await setSubscription(String(ctx.chat.id), true);
  await ctx.reply("🔔 Scheduled reports enabled.");
});

bot.command("unsubscribe", async ctx => {
  await upsertUser(ctx);
  await setSubscription(String(ctx.chat.id), false);
  await ctx.reply("🔕 Scheduled reports disabled. You can still use commands.");
});

bot.command("analysis", async ctx => {
  const symbol = (ctx.message.text.split(/\s+/)[1] || "").toUpperCase();
  if (!validSymbol(symbol)) return ctx.reply("Usage: /analysis RELIANCE");
  await upsertUser(ctx);
  const status = await ctx.reply(`Analyzing ${symbol}...`);
  try {
    const result = await scanSymbol(symbol, true);
    await ctx.telegram.editMessageText(
      ctx.chat.id, status.message_id, undefined, formatResult(result),
      { parse_mode: "HTML" }
    );
  } catch (error) {
    await ctx.reply(`Could not analyze ${symbol}: ${error.message}`);
  }
});

bot.command("market", async ctx => {
  const user = await upsertUser(ctx);
  const symbols = user.watchlist?.length ? user.watchlist : config.symbols;
  await ctx.reply(`Scanning ${symbols.length} stocks. This may take a little while...`);
  const results = await scanSymbols(symbols, true);
  for (const result of results) {
    await ctx.reply(formatResult(result), { parse_mode: "HTML" });
  }
});

bot.catch((error, ctx) => {
  console.error("Telegram bot error:", error);
  ctx.reply("Something went wrong. Please try again later.").catch(() => {});
});
