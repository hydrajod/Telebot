import cron from "node-cron";
import { bot } from "../bot.js";
import { config } from "../config.js";
import { getSubscribers } from "../database.js";
import { scanSymbols, formatResult } from "../services/scanner.js";

async function scheduledScan(label) {
  console.log(`Starting scheduled scan: ${label}`);
  const subscribers = await getSubscribers();
  if (!subscribers.length) return;

  const results = await scanSymbols(config.symbols, true);
  const candidates = results.filter(r =>
    !r.error && r.metrics.signal !== "WAIT"
  );

  const summary = candidates.length
    ? `📊 <b>StockPilot ${label}</b>\n\n` +
      candidates.map(formatResult).join("\n\n────────────\n\n")
    : `📊 <b>StockPilot ${label}</b>\n\nNo qualifying bullish or bearish setups found in the configured universe.\n\nNo signal is also a useful result.`;

  for (const user of subscribers) {
    try {
      // Telegram messages have a 4096-character limit.
      const chunks = splitMessage(summary, 3800);
      for (const chunk of chunks) {
        await bot.telegram.sendMessage(user.chatId, chunk, { parse_mode: "HTML" });
      }
    } catch (error) {
      console.error(`Could not notify ${user.chatId}:`, error.message);
    }
  }
}

function splitMessage(text, maxLength) {
  if (text.length <= maxLength) return [text];
  const blocks = text.split("\n\n────────────\n\n");
  const chunks = [];
  let current = "";
  for (const block of blocks) {
    if ((current + block).length > maxLength && current) {
      chunks.push(current);
      current = "";
    }
    current += (current ? "\n\n────────────\n\n" : "") + block;
  }
  if (current) chunks.push(current);
  return chunks;
}

export function startScheduler() {
  // Weekdays only; exchange holidays are not automatically excluded.
  cron.schedule("25 9 * * 1-5", () => scheduledScan("Opening scan"), { timezone: "Asia/Kolkata" });
  cron.schedule("30 12 * * 1-5", () => scheduledScan("Midday scan"), { timezone: "Asia/Kolkata" });
  cron.schedule("15 15 * * 1-5", () => scheduledScan("Closing scan"), { timezone: "Asia/Kolkata" });
  console.log("Scheduler enabled: 09:25, 12:30 and 15:15 IST, Monday-Friday.");
}
