import mongoose from "mongoose";
import { config } from "./config.js";

const userSchema = new mongoose.Schema({
  chatId: { type: String, unique: true, required: true, index: true },
  username: String,
  subscribed: { type: Boolean, default: true },
  watchlist: { type: [String], default: [] },
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model("User", userSchema);

export async function connectDatabase() {
  await mongoose.connect(config.mongoUri);
  console.log("MongoDB connected");
}

export async function upsertUser(ctx) {
  const chatId = String(ctx.chat.id);
  return User.findOneAndUpdate(
    { chatId },
    {
      $set: { username: ctx.from?.username || "" },
      $setOnInsert: { watchlist: config.symbols.slice(0, 10), subscribed: true }
    },
    { upsert: true, new: true }
  );
}

export async function getUser(chatId) {
  return User.findOne({ chatId });
}

export async function updateWatchlist(chatId, watchlist) {
  return User.findOneAndUpdate({ chatId }, { $set: { watchlist } }, { new: true });
}

export async function setSubscription(chatId, subscribed) {
  return User.findOneAndUpdate({ chatId }, { $set: { subscribed } }, { new: true });
}

export async function getSubscribers() {
  return User.find({ subscribed: true }).select("chatId").lean();
}

export async function getAllUsers() {
  return User.find({}).select("chatId watchlist").lean();
}
